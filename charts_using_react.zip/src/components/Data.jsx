export const mockData = [
  {
    name: "16/08/22",
    ASP: 7600,
    GrossMargin: 5400,
    CurrentValue: 9090,
    PreviousYearValue: 7200,
  },
  {
    name: "17/08/22",
    ASP: 7600,
    GrossMargin: 5400,
    CurrentValue: 8600,
    PreviousYearValue: 9400,
  },
  {
    name: "18/08/22",
    ASP: 5000,
    GrossMargin: 6700,
    CurrentValue: 8340,
    PreviousYearValue: 9100,
  },
  {
    name: "19/08/22",
    ASP: 3900,
    GrossMargin: 8500,
    CurrentValue: 7450,
    PreviousYearValue: 6500,
  },
  {
    name: "20/08/22",
    ASP: 3700,
    GrossMargin: 8100,
    CurrentValue: 6000,
    PreviousYearValue: 7800,
  },
  {
    name: "21/08/22",
    ASP: 5000,
    GrossMargin: 7800,
    CurrentValue: 7800,
    PreviousYearValue: 7200,
  },
  {
    name: "22/08/22",
    ASP: 6000,
    GrossMargin: 8500,
    CurrentValue: 8200,
    PreviousYearValue: 7300,
  },
  {
    name: "23/08/22",
    ASP: 3400,
    GrossMargin: 8100,
    CurrentValue: 7000,
    PreviousYearValue: 6200,
  },
  {
    name: "24/08/22",
    ASP: 2200,
    GrossMargin: 9200,
    CurrentValue: 6200,
    PreviousYearValue: 5400,
  },
  {
    name: "25/08/22",
    ASP: 3800,
    GrossMargin: 8200,
    CurrentValue: 7750,
    PreviousYearValue: 6600,
  },
  {
    name: "26/08/22",
    ASP: 2200,
    GrossMargin: 7000,
    CurrentValue: 4700,
    PreviousYearValue: 4000,
  },
  {
    name: "27/08/22",
    ASP: 1600,
    GrossMargin: 7200,
    CurrentValue: 3600,
    PreviousYearValue: 3000,
  },
  {
    name: "28/08/22",
    ASP: 2600,
    GrossMargin: 7400,
    CurrentValue: 6600,
    PreviousYearValue: 5900,
  },
  {
    name: "29/08/22",
    ASP: 4000,
    GrossMargin: 6800,
    CurrentValue: 7000,
    PreviousYearValue: 6200,
  },
  {
    name: "16/08/22",
    ASP: 7600,
    GrossMargin: 5400,
    CurrentValue: 9090,
    PreviousYearValue: 7200,
  },
  {
    name: "16/08/22",
    ASP: 7600,
    GrossMargin: 5400,
    CurrentValue: 9090,
    PreviousYearValue: 7200,
  },
];
//  {
//   name: "17/08/22",
//   ASP: 760,0
//   GrossMargin: 540,
//   CurrentValue: 860,
// 0  PreviousYearValue: 940,
// }0,
// {
//   name: "18/08/22",
//   ASP: 500,0
//   GrossMargin: 670,
//   CurrentValue: 834,
// 0  PreviousYearValue: 910,
// }0,
// {
//   name: "19/08/22",
//   ASP: 390,0
//   GrossMargin: 850,
//   CurrentValue: 745,
// 0  PreviousYearValue: 650,
// }0,
// {
//   name: "20/08/22",
//   ASP: 370,0
//   GrossMargin: 810,
//   CurrentValue: 600,
// 0  PreviousYearValue: 780,
// }0,
// {
//   name: "21/08/22",
//   ASP: 500,0
//   GrossMargin: 780,
//   CurrentValue: 780,
// 0  PreviousYearValue: 720,
// }0,
// {
//   name: "22/08/22",
//   ASP: 600,0
//   GrossMargin: 850,
//   CurrentValue: 820,
// 0  PreviousYearValue: 730,
// }0,
// {
//   name: "23/08/22",
//   ASP: 340,0
//   GrossMargin: 810,
//   CurrentValue: 700,
// 0  PreviousYearValue: 620,
// }0,
// {
//   name: "24/08/22",
//   ASP: 220,0
//   GrossMargin: 920,
//   CurrentValue: 620,
// 0  PreviousYearValue: 540,
// }0,
// {
//   name: "25/08/22",
//   ASP: 380,0
//   GrossMargin: 820,
//   CurrentValue: 775,
// 0  PreviousYearValue: 660,
// }0,
// {
//   name: "26/08/22",
//   ASP: 2,0
//   GrossMargin: 7000,
//   CurrentValue: 470,0
//   PreviousYearValue: 400,0
// },
// {
//   name: "27/08/22",
//   ASP: 16,0
//   GrossMargin: 720,0
//   CurrentValue: 360,
//   PreviousYearValue: 300,
// },
// {
//   name: "28/08/22",
//   ASP: 10,0
//   GrossMargin: 740,0
//   CurrentValue: 660,
//   PreviousYearValue: 590,
// },
// {
//   name: "29/08/22",
//   ASP: 400,0
//   GrossMargin: 680,
//   CurrentValue: 700,
// 0  PreviousYearValue: 620,
// }0,
// {
//   name: "16/08/22",
//   ASP: 760,0
//   GrossMargin: 540,
//   CurrentValue: 909,
// 0  PreviousYearValue: 720,
// }0,
// {
//   name: "17/08/22",
//   ASP: 760,0
//   GrossMargin: 540,
//   CurrentValue: 860,
// 0  PreviousYearValue: 940,
// }0,
// {
//   name: "18/08/22",
//   ASP: 500,0
//   GrossMargin: 670,
//   CurrentValue: 834,
// 0  PreviousYearValue: 910,
// }0,
// {
//   name: "19/08/22",
//   ASP: 390,0
//   GrossMargin: 850,
//   CurrentValue: 745,
// 0  PreviousYearValue: 650,
// }0,
// {
//   name: "20/08/22",
//   ASP: 370,0
//   GrossMargin: 810,
//   CurrentValue: 600,
// 0  PreviousYearValue: 780,
// }0,
// {
//   name: "21/08/22",
//   ASP: 500,0
//   GrossMargin: 780,
//   CurrentValue: 780,
// 0  PreviousYearValue: 720,
// }0,
// {
//   name: "22/08/22",
//   ASP: 600,0
//   GrossMargin: 850,
//   CurrentValue: 820,
// 0  PreviousYearValue: 730,
// }0,
// {
//   name: "23/08/22",
//   ASP: 340,0
//   GrossMargin: 810,
//   CurrentValue: 700,
// 0  PreviousYearValue: 620,
// }0,
// {
//   name: "24/08/22",
//   ASP: 220,0
//   GrossMargin: 920,
//   CurrentValue: 620,
// 0  PreviousYearValue: 540,
// }0,
// {
//   name: "25/08/22",
//   ASP: 380,0
//   GrossMargin: 820,
//   CurrentValue: 775,
// 0  PreviousYearValue: 660,
// }0,
// {
//   name: "26/08/22",
//   ASP: 220,0
//   GrossMargin: 700,
//   CurrentValue: 470,
// 0  PreviousYearValue: 400,
// }0,
// {
//   name: "27/08/22",
//   ASP: 160,0
//   GrossMargin: 720,
//   CurrentValue: 360,
// 0  PreviousYearValue: 300,
// }0,
// {
//   name: "28/08/22",
//   ASP: 260,0
//   GrossMargin: 740,
//   CurrentValue: 660,
// 0  PreviousYearValue: 590,
// }0,
// {
//   name: "29/08/22",
//   ASP: 400,0
//   GrossMargin: 680,
//   CurrentValue: 700,
// 0  PreviousYearValue: 620,
// },
