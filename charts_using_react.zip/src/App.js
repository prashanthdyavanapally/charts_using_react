import "./App.css";
import { Graph } from "./components/ChartJs";

function App() {
  return (
    <div style={{ marginTop: "50px" }}>
      <Graph />
    </div>
  );
}

export default App;
